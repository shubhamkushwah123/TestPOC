package org.bliffoscope.main.app;

import java.util.ArrayList;
import java.util.Collections;

import org.bliffoscope.pojo.Location;
import org.bliffoscope.pojo.Constants;
import org.bliffoscope.pojo.RawInputSpace;
import org.bliffoscope.pojo.SlimeTorpedo;
import org.bliffoscope.pojo.SpaceFactory;
import org.bliffoscope.pojo.SpaceObjects;
import org.bliffoscope.pojo.SpaceShip;
import org.bliffoscope.services.impl.BliffoScopeImageDetectorServiceImpl;
import org.bliffoscope.services.impl.interfaces.BliffoScopeImageDetectorServiceInterface;


public class Bliffoscope {
	
	public static void main(String args[]){
	
		ArrayList<Location> matchedTorpedosList = new ArrayList<Location>();	
		
		ArrayList<Location> matchedSpaceShipsList = new ArrayList<Location>();
			
	SpaceFactory spaceFactory = new SpaceFactory();
	//Read Torpedo 
	//SlimeTorpedo tarpedo = new SlimeTorpedo(Constants.SLIME_TORPEDO);
	SpaceObjects tarpedo = spaceFactory.getInstance(Constants.SLIME_TORPEDO);
	tarpedo.readBlfFile(tarpedo.getFileLocation(), tarpedo.getWidth(), tarpedo.getHeight());
	tarpedo.calculateOnPixels(tarpedo.getAntiNeutrinoImage());
	
	//Read SpaceShip
	//SpaceShip spaceShip = new SpaceShip(Constants.SPACE_SHIP);
	SpaceObjects spaceShip = spaceFactory.getInstance(Constants.SPACE_SHIP);
	spaceShip.readBlfFile(spaceShip.getFileLocation(), spaceShip.getWidth(), spaceShip.getHeight());
	spaceShip.calculateOnPixels(spaceShip.getAntiNeutrinoImage());
	
	//Read InputSpaceStream
	//RawInputSpace inputSpace= new RawInputSpace(Constants.INPUT_RAW_SPACE);
	SpaceObjects inputSpace = spaceFactory.getInstance(Constants.INPUT_RAW_SPACE);
	inputSpace.readBlfFile(inputSpace.getFileLocation(), inputSpace.getWidth(), inputSpace.getHeight());
	
	
	BliffoScopeImageDetectorServiceInterface service = new BliffoScopeImageDetectorServiceImpl();
	
	//Detect Torpedo in SpaceStream
	matchedTorpedosList = service.DetectSpaceItem(tarpedo, inputSpace);
	for(Location location:matchedTorpedosList)
		System.out.print(Math.round(location.getScore()));
	Collections.sort(matchedTorpedosList);
		for(Location location:matchedTorpedosList)
		System.out.print(Math.round(location.getScore()) + ",");
	service.printSpaceObjectsIdentified(matchedTorpedosList,tarpedo);
	
	//Detect Spaceship in Spacesteam
	matchedSpaceShipsList = service.DetectSpaceItem(spaceShip, inputSpace);
	Collections.sort(matchedSpaceShipsList);
	service.printSpaceObjectsIdentified(matchedSpaceShipsList,spaceShip);
	
	
	

}
}

