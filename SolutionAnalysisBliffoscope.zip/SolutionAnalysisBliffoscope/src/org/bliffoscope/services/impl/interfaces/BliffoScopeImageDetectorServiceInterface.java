package org.bliffoscope.services.impl.interfaces;

import java.util.ArrayList;


import org.bliffoscope.pojo.Location;
import org.bliffoscope.pojo.RawInputSpace;
import org.bliffoscope.pojo.SlimeTorpedo;
import org.bliffoscope.pojo.SpaceObjects;

public interface BliffoScopeImageDetectorServiceInterface {

	public ArrayList<Location> DetectSpaceItem(SpaceObjects torpedo, SpaceObjects inputSpace);

	public void printSpaceObjectsIdentified(ArrayList<Location> matchedObjList, SpaceObjects spaceObj);

}
