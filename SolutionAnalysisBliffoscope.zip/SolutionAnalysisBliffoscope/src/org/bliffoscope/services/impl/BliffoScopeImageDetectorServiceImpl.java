package org.bliffoscope.services.impl;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;




import org.bliffoscope.pojo.Location;
import org.bliffoscope.pojo.RawInputSpace;
import org.bliffoscope.pojo.SlimeTorpedo;
import org.bliffoscope.pojo.SpaceObjects;
import org.bliffoscope.pojo.SpaceShip;
import org.bliffoscope.services.impl.interfaces.BliffoScopeImageDetectorServiceInterface;

public class BliffoScopeImageDetectorServiceImpl implements BliffoScopeImageDetectorServiceInterface {

	
	public ArrayList<Location> DetectSpaceItem(SpaceObjects torpedo, SpaceObjects inputSpace) {
		
		boolean antiNeutrinoSpaceObject[][]= torpedo.getAntiNeutrinoImage();
		
		boolean antiNeutrinoInputSpaceStream[][]=inputSpace.getAntiNeutrinoImage();
		
		ArrayList<Location> itemLocationList = new ArrayList<Location>();
		
		int matchScore;
		
		for(int row=0;row<antiNeutrinoInputSpaceStream.length;row++){
			for(int col=0;col<antiNeutrinoInputSpaceStream[row].length;col++){
				Location location = new Location();
				matchScore=0;
				
				for(int objRow=0;objRow<antiNeutrinoSpaceObject.length;objRow++){
					for(int objCol=0;objCol<antiNeutrinoSpaceObject[objRow].length
						&& objRow+row<antiNeutrinoInputSpaceStream.length
						&& objCol+col<antiNeutrinoInputSpaceStream[row].length;objCol++){
								
							if(antiNeutrinoSpaceObject[objRow][objCol]){
									
								if(antiNeutrinoSpaceObject[objRow][objCol]==antiNeutrinoInputSpaceStream[row+objRow][col+objCol]){
											matchScore++;
								}
							}		
					}
				
				}

				location.setLocationX(row);
				location.setLocationY(col);
				location.setScore(matchScore);
				itemLocationList.add(location);
				
			}
		}
		return itemLocationList;
	}

	
	@Override
	public void printSpaceObjectsIdentified(ArrayList<Location> matchedObjList, SpaceObjects spaceObj) {
		// TODO Auto-generated method stub
	
		if (spaceObj instanceof SlimeTorpedo) {
			System.out.println("It is an Instance of slime Tarpedo");
			print(matchedObjList, spaceObj.getFileName(), spaceObj.getTotalOnPixels());
		}
		else if(spaceObj instanceof SpaceShip){
			System.out.println("It is an Instance of SpaceShip");
			print(matchedObjList, spaceObj.getFileName(), spaceObj.getTotalOnPixels());
		}
		else{
			System.out.println("Invalid input");
		}
		
		
		
		
	}

	private void print(ArrayList<Location> matchedObjList, String fileName, int totalOnPixels) {
		
		for(Location location:matchedObjList){
			
			float confidence = calculateProbability(location.getScore(),totalOnPixels);
			
			if(confidence>70){
				System.out.println("Item Detected : " + fileName);
				System.out.println("Confidence : " + confidence);
				System.out.println("Location(x,y) : " + location.getLocationX()+","+location.getLocationY());
			}
			else if(confidence>60){
				System.out.println("Item Detected" + fileName);
				System.out.println("Confidence" + confidence);
				System.out.println("Location(x,y)" + location.getLocationX()+","+location.getLocationY());
			}
			/*else if(confidence>50){
				System.out.println("Item Detected" + fileName);
				System.out.println("Confidence" + confidence);
				System.out.println("Location(x,y)" + location.getLocationX()+","+location.getLocationY());
			}*/
		}
	}

	private float calculateProbability(float score, int totalOnPixels) {
		return Math.round((score/totalOnPixels)*100);
	}



	

	

	
}

