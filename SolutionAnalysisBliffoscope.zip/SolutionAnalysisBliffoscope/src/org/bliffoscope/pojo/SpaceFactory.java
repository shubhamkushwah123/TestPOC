package org.bliffoscope.pojo;

import org.bliffoscope.services.impl.BliffoScopeImageDetectorServiceImpl;

public class SpaceFactory {
	
	public SpaceObjects getInstance(String obj){
		if(obj.equalsIgnoreCase(Constants.SLIME_TORPEDO)){
			return new SlimeTorpedo(obj);
		}
		
		if(obj.equalsIgnoreCase(Constants.SPACE_SHIP)){
			return new SpaceShip(obj);
		}
		
		if(obj.equalsIgnoreCase(Constants.INPUT_RAW_SPACE)){
			return new RawInputSpace(obj);
		}
		
		else{
			System.out.println("Invalid Parameter");
			return null;
		}
		
		
	}

}
