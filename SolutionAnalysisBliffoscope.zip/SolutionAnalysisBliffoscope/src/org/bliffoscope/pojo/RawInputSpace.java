package org.bliffoscope.pojo;

public class RawInputSpace extends SpaceObjects {

	public RawInputSpace(String objectName) {
		super(objectName);
	}

	
}
