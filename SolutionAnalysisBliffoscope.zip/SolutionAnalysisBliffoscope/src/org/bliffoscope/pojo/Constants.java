package org.bliffoscope.pojo;

public class Constants {
	
	public static final String SLIME_TORPEDO="SlimeTorpedo";
	
	public static final String SPACE_SHIP="Starship";
	
	public static final String INPUT_RAW_SPACE="TestData";
	
	public static final String F_SLASH="/";
	
	public static final String BLF_EXTENTION=".blf";
	
	

}
