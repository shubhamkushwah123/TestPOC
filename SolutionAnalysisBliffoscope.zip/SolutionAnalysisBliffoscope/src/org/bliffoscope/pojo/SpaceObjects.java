package org.bliffoscope.pojo;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


public class SpaceObjects {
	
	private String fileName;
	
	private String fileLocation;
	
	private int height;
	
	private int width;
	
	private int totalOnPixels;
	
	private boolean[][] antiNeutrinoImage;

	
	public String getFileLocation(String fileName) {
		return Constants.F_SLASH + fileName + Constants.BLF_EXTENTION;
	}

	public String getFileLocation() {
		return fileLocation;
	}
	
	public void setFileLocation(String fileLocation) {
		this.fileLocation=fileLocation;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public boolean[][] getAntiNeutrinoImage() {
		return antiNeutrinoImage;
	}

	public void setAntiNeutrinoImage(boolean[][] antiNeutrinoImage) {
		this.antiNeutrinoImage = antiNeutrinoImage;
	}
	
	public SpaceObjects(String fileName){
		
		this.fileName=fileName;
		this.fileLocation=getFileLocation(fileName);
		int capacity=calculateSpaceItemCapacity(fileLocation);
		this.width=capacity;
		this.height=capacity;
		antiNeutrinoImage = new boolean[width][height];
		this.totalOnPixels = 0;
	}
	
	public int getTotalOnPixels() {
		return totalOnPixels;
	}

	public void setTotalOnPixels(int totalOnPixels) {
		this.totalOnPixels = totalOnPixels;
	}

	public boolean[][] readBlfFile(String fileLocation, int width, int height) {
		System.out.println("readBLFFile" + fileName);
		 try {
	            InputStream is = null;
	            InputStream in;
	                in = this.getClass().getResourceAsStream(fileLocation);
	                if (in == null) {
	                    try {
	                        throw new FileNotFoundException("File not found in classpath: " + fileName);
	                    } catch (FileNotFoundException e) {
	                        e.printStackTrace();
	                    }
	                }  else {
	                    is = new BufferedInputStream(in);
	                }
	            
	            if(is!=null) {
	                BufferedReader reader = new BufferedReader(new InputStreamReader(is,"utf-8"));

	                String line;
	                int col;
	                int row = 0;
	                while((line = reader.readLine()) != null && row < height) {
	                                                     for(col = 0; col < line.length() && col < width; col++) {
	                        //in further versions we may want to stop hard-coding '+' so it can be configured.
	                                      antiNeutrinoImage[row][col] = line.charAt(col) == '+';
	                                
	                    }
	                    row++;
	                }
	                reader.close();
	            }
	        } catch(IOException e) {
	            e.printStackTrace();
	        }
	        return antiNeutrinoImage;
		
	}

	
	public int calculateSpaceItemCapacity(String fileLocation) {
		int lineCount = 0;
        int maxCharsInLine = 0;

        InputStream is;

        //Safe use of getResource as no relative path would be used - but we should take this into account.
        InputStream in = this.getClass().getResourceAsStream(fileLocation);
        if (in == null) {
            try {
                throw new FileNotFoundException("File not found in classpath: " + fileName);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        is = new BufferedInputStream(in);
        
        try {
            byte[] c = new byte[1024];
            int readChars;
            boolean endsWithoutNewLine = false;
            while ((readChars = is.read(c)) != -1) {
                for (int i = 0, j = 0; i < readChars; ++i, ++j) {
                    if (c[i] == '\n') {
                        ++lineCount;
                        maxCharsInLine = (j > maxCharsInLine) ? j : maxCharsInLine;
                        j=0;
                    }
                }
                endsWithoutNewLine = (c[readChars - 1] != '\n');
            }
            if(endsWithoutNewLine) {
                ++lineCount;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return (lineCount > maxCharsInLine) ? lineCount : maxCharsInLine;
	}

	public int calculateOnPixels(boolean[][] antiNeutrinoImage){
		
		for(int row=0;row<antiNeutrinoImage.length;row++){
			for(int col=0;col<antiNeutrinoImage[row].length;col++){
				if(antiNeutrinoImage[row][col]){
					totalOnPixels++;
				}
			}
			
		}
		
		return totalOnPixels;
	}

	
}
