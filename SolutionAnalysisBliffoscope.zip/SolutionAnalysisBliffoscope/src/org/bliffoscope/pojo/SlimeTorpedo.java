package org.bliffoscope.pojo;

public class SlimeTorpedo extends SpaceObjects {
	
	public SlimeTorpedo(String objectName) {
		super(objectName);
	}
}
