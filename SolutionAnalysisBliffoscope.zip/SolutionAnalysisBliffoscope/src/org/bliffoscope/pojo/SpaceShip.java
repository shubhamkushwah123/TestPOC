package org.bliffoscope.pojo;

public class SpaceShip extends SpaceObjects {

	public SpaceShip(String objectName) {
		super(objectName);
	}


}
