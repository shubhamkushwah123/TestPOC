package org.bliffoscope.pojo;

public class Location implements Comparable<Location>{
	
	private float score;
	
	private int locationX;
	
	private int locationY;

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public int getLocationX() {
		return locationX;
	}

	public void setLocationX(int locationX) {
		this.locationX = locationX;
	}

	public int getLocationY() {
		return locationY;
	}

	public void setLocationY(int locationY) {
		this.locationY = locationY;
	}

	@Override
	public int compareTo(Location location) {
		if(score > location.getScore())
			return -1;
		else if(score < location.getScore())
			return 1;
		else
			return 0;
	}

	
	
}
